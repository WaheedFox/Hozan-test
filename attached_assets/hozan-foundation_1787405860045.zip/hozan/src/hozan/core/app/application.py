from __future__ import annotations

from dataclasses import dataclass

from hozan.core.lifecycle.runtime import Lifecycle
from hozan.platform.telegram.application import TelegramApplication


@dataclass(slots=True)
class HozanApplication:
    """Hozan composition root."""

    telegram: TelegramApplication
    lifecycle: Lifecycle

    @classmethod
    def create(cls, token: str) -> "HozanApplication":
        return cls(TelegramApplication(token), Lifecycle())

    async def start(self) -> None:
        await self.telegram.start(self.lifecycle)

    async def stop(self) -> None:
        await self.telegram.stop(self.lifecycle)
